<?php
// Start session or include necessary files if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointment System</title>
</head>
<body>
    <h1>Welcome to the Appointment System</h1>
    <a href="appointment-form.php">Book an Appointment</a>
</body>
</html>
